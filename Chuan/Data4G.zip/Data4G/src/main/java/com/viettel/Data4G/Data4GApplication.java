package com.viettel.Data4G;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Data4GApplication {

	public static void main(String[] args) {
		SpringApplication.run(Data4GApplication.class, args);
	}

}
