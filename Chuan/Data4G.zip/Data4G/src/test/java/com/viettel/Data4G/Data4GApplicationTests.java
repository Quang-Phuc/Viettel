package com.viettel.Data4G;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Data4GApplicationTests {

	@Test
	void contextLoads() {
	}

}
